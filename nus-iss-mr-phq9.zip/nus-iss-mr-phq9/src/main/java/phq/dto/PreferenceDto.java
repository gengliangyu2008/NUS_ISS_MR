package phq.dto;

public class PreferenceDto {

    private String practitionerRole = "0";
    private String language = "0";
    private String practitionerGender = "0";
    private String institutionLocation = "0";
    private String sessionDay = "0";

    public String getPractitionerRole() {
        return practitionerRole;
    }

    public void setPractitionerRole(String practitionerRole) {
        this.practitionerRole = practitionerRole;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getPractitionerGender() {
        return practitionerGender;
    }

    public void setPractitionerGender(String practitionerGender) {
        this.practitionerGender = practitionerGender;
    }

    public String getInstitutionLocation() {
        return institutionLocation;
    }

    public void setInstitutionLocation(String institutionLocation) {
        this.institutionLocation = institutionLocation;
    }

    public String getSessionDay() {
        return sessionDay;
    }

    public void setSessionDay(String sessionDay) {
        this.sessionDay = sessionDay;
    }
}
