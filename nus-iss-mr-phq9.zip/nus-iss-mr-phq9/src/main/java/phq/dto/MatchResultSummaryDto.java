package phq.dto;

import java.util.List;

public class MatchResultSummaryDto {
    private String summary;
    private List<MatchResultDto> matchedList;

    public MatchResultSummaryDto(String summary, List<MatchResultDto> matchedList) {
        this.summary = summary;
        this.matchedList = matchedList;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public List<MatchResultDto> getMatchedList() {
        return matchedList;
    }

    public void setMatchedList(List<MatchResultDto> matchedList) {
        this.matchedList = matchedList;
    }
}
