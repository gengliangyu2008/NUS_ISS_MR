package database;

import java.sql.*;

public class DBUtils {
    public static final String URL = "jdbc:derby://localhost:1527/phq-db;create=true;user=phqadmin;password=phqadmin";
    public static final String DRIVER = "org.apache.derby.jdbc.ClientDriver";

    public static final String EMBEDDED_URL = "jdbc:derby:phq-db;create=true;user=app;password=app";
    public static final String EMBEDDED_DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";

    private DBConnection dbConnection = new DBConnection();
    private Connection connection = dbConnection.getConn();
    private Statement statement = null;
    private ResultSet resultSet = null;

    public DBUtils() throws Exception {
        try {

            Class.forName(EMBEDDED_DRIVER).newInstance();
            connection = DriverManager.getConnection(EMBEDDED_URL);

            /*PreparedStatement statement = connection
                    .prepareStatement("SELECT * from USERS");

            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                String user = resultSet.getString("name");
                String number = resultSet.getString("number");
                System.out.println("User: " + user);
                System.out.println("ID: " + number);
            }*/
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            close();
        }
    }


    public void insertPatientRecord() throws Exception {
        try {


            PreparedStatement statement = connection
                    .prepareStatement("SELECT * from USERS");

            resultSet = statement.executeQuery();
            while (resultSet.next()) {
                String user = resultSet.getString("name");
                String number = resultSet.getString("number");
                System.out.println("User: " + user);
                System.out.println("ID: " + number);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            close();
        }
    }

    private void close() {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws Exception {
        DBUtils dao = new DBUtils();
    }
}
