package com.phqtime.phqtimetable;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("PhqInstitution")
public class PhqInstitution implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long id;
	private String name;
	private String location;
	private String type;
	private String address;
	
	public PhqInstitution() {
		
	}
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public PhqInstitution(long id, String name, String location, String type, String address) {
		this.id = id;
		this.name = name;
		this.location = location;
		this.type = type;
		this.address = address;
	}
	
	public String getDesc() {
		StringBuffer buf = new StringBuffer();
		buf.append("id: ").append(id).append(", ");
		buf.append("name: ").append(name).append(", ");
		buf.append("location: ").append(location).append(", ");
		buf.append("type: ").append(type).append(", ");
		buf.append("address: ").append(address).append(", ");
		
		return buf.toString();
	}
}
