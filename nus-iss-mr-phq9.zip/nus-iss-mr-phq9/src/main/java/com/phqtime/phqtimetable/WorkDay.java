package com.phqtime.phqtimetable;

import java.io.Serializable;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("WorkDay")
public class WorkDay implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	private static final String[] WEEKDAYS = {"Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"};

    
	private long id;

    private int dayIndex;

    private List<WorkPeriod> periodList;

    public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getDayIndex() {
        return dayIndex;
    }

    public void setDayIndex(int dayIndex) {
        this.dayIndex = dayIndex;
    }

    public List<WorkPeriod> getPeriodList() {
        return periodList;
    }

    public void setPeriodList(List<WorkPeriod> periodList) {
        this.periodList = periodList;
    }

    public String getDesc() {
        String weekday = WEEKDAYS[dayIndex % WEEKDAYS.length];
        if (dayIndex > WEEKDAYS.length) {
            return "Day " + dayIndex;
        }
        return weekday;
    }

    public static int getWorkDaySize() {
    	return WEEKDAYS.length;
    }
    
    public static WorkDay getWorkDay(String workDayDesc, List<WorkDay> workDayList) {
    	int workDayIndex = getWorkDayIndex(workDayDesc);
    	if (workDayIndex < 0) {
    		return null;
    	}
    	
    	return workDayList.get(workDayIndex);
    }
    
    public static int getWorkDayIndex(String workDayDesc) {
    	int dayIndex = -1;
    	for (int i = 0; i < WEEKDAYS.length; ++i) {
    		if (WEEKDAYS[i].equalsIgnoreCase(workDayDesc)) {
    			dayIndex = i;
    			break;
    		}
    	}
    	
    	return dayIndex;
    }
    
    @Override
    public String toString() {
        return Integer.toString(dayIndex);
    }

    public WorkDay(long id, int dayIndex) {
    	this.id = id;
    	this.dayIndex = dayIndex;
    }
}
