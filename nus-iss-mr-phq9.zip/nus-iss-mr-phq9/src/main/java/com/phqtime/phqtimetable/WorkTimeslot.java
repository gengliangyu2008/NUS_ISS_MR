package com.phqtime.phqtimetable;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("WorkTimeslot")
public class WorkTimeslot implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final String[] TIMES = {"08:00 - 9:59", "10:00 - 11:59", "14:00 - 15:59", "16:00 - 17:59"};

	private long id;
	private int timeslotIndex;

    public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getTimeslotIndex() {
        return timeslotIndex;
    }

    public void setTimeslotIndex(int timeslotIndex) {
        this.timeslotIndex = timeslotIndex;
    }

    public String getDesc() {
        String time = TIMES[timeslotIndex % TIMES.length];
        if (timeslotIndex > TIMES.length) {
            return "Timeslot " + timeslotIndex;
        }
        return time;
    }

    public static int getTimeslotSize() {
    	return TIMES.length;
    }
    
    @Override
    public String toString() {
        return Integer.toString(timeslotIndex);
    }

    public WorkTimeslot(long id, int timeslotIndex) {
    	this.id = id;
    	this.timeslotIndex = timeslotIndex;
    }
    
}
