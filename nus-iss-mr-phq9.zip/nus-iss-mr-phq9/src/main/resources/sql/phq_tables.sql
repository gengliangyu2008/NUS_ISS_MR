/*
create table phq_patient_preference(
sno int primary key,
phq_score int,
session_hours_needed int,
practitioner_role varchar(32),
practitioner_language varchar(32),
practitioner_gender varchar(32),
institution_location varchar(32),
session_day varchar(32)
);

create table phq_practioner_availability(
sno int primary key,
practitioner_name varchar(64),
practitioner_role varchar(32),

practitioner_mon varchar(256),
practitioner_tue varchar(256),
practitioner_wed varchar(256),
practitioner_thu varchar(256),
practitioner_fri varchar(256),
practitioner_sat varchar(256),
practitioner_sun varchar(256),

practitioner_language varchar(32),
practitioner_gender varchar(32),
practitioner_cost varchar(8),
institution_name varchar(128),
institution_type varchar(64),
institution_location_overall varchar(64),
institution_location_detail varchar(256),
institution_day varchar(256),
institution_hour varchar(256),
institution_contact_detail varchar(256),
note varchar(256)
);
*/

drop table phq_patient_preference;
drop table phq_practioner_availability;


create table phq_patient_preference(
sno int primary key,
phq_score int,
practitioner_role varchar(32),
practitioner_language varchar(32),
practitioner_gender varchar(32),
institution_location varchar(32),
session_day varchar(32)
);

create table phq_practioner_availability(
sno int primary key,
practitioner_name varchar(64),
practitioner_role varchar(32),

practitioner_language varchar(32),
practitioner_gender varchar(32),
practitioner_cost varchar(8),

practitioner_mon varchar(256),
practitioner_tue varchar(256),
practitioner_wed varchar(256),
practitioner_thu varchar(256),
practitioner_fri varchar(256),
practitioner_sat varchar(256),
practitioner_sun varchar(256),

institution_name varchar(128),
institution_type varchar(64),
institution_location_overall varchar(64),
institution_location_detail varchar(256)
);